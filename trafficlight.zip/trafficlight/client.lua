-- Creating locals in global scope to sync across entire script and get some performance back
local playerPed = PlayerPedId()
local playerPos = GetEntityCoords(playerPed)
local playerVeh = GetVehiclePedIsIn(playerPed)
local playerRot = GetEntityRotation(playerPed) -- This returns vector3

local threadsRunning = false

local acceptableObjects = {
	`prop_traffic_01a`,
	`prop_traffic_01b`,
	`prop_traffic_01d`,
	`prop_traffic_02a`,
	`prop_traffic_02b`,
	`prop_traffic_03a`,
	`prop_traffic_03b`,
	`prop_traffic_lightset_01` -- Might not work
}
local objects = {}



-- Updating some locals like player position, medium priority
CreateThread(function()
	while true do
		playerPed = PlayerPedId()
		playerPos = GetEntityCoords(playerPed)
		playerVeh = GetVehiclePedIsIn(playerPed)
		playerRot = GetEntityRotation(playerPed)
		Wait(0)
	end
end)



-- Updating the objects table every second
function startObjectFindLoop()

	-- Updating the objects table in this thread, low priority
	CreateThread(function()
		while threadsRunning do

			-- Create a new objects table to apply the change at once
			local newObjects = {}

			-- Start looking for objects
			local findHandle, foundObject = FindFirstObject()

			-- Nothing found, end search
			if foundObject == -1 then
				EndFindObject(findHandle)
				print("No object found, ending loop prematurely")

			-- Something found, keep looking in a loop
			else
				local success = true
				--[[ Old method. Worked, but slow as f*ck.
				while success and threadsRunning do

					-- Check most recently found object if it is what we're looking for
					local hash = GetEntityModel(foundObject)
					for i = 1, #acceptableObjects do
						if acceptableObjects[i] == hash then
							table.insert(newObjects, foundObject)
							break
						end
					end

					-- Find the next object
					success, foundObject = FindNextObject(findHandle)
					Wait(0)
				end]]

				-- New method, much faster. Might lag on low end specs, not sure.
				for i = 1, 10000 do
					if success and threadsRunning then

						-- Check most recently found object if it is what we're looking for
						local hash = GetEntityModel(foundObject)
						for i = 1, #acceptableObjects do
							if acceptableObjects[i] == hash then
								table.insert(newObjects, foundObject)
								break
							end
						end

						-- Find the next object
						success, foundObject = FindNextObject(findHandle)
					else
						objects = newObjects
						break
					end
				end

				-- Success set to false meaning no further objects found, end search
				EndFindObject(findHandle)
			end
			Wait(100)
		end
	end)

	-- Iterating objects table to get distance, rotation, etc. in this thread, high priority
	CreateThread(function()
		while threadsRunning do

			-- Creating copy of objects table in case it gets cleared while iterating it, breaking everything
			local _objects = objects

			-- For every object
			for _, v in pairs(_objects) do

				-- Get the prop data
				local objPos = GetEntityCoords(v)
				-- local objDist = #(objPos - playerPos)
				local objRot = GetEntityRotation(v)
				local relativeRot = objRot.z - playerRot.z

				-- If rotation relative to prop is +/-30°
				if relativeRot >= (-30) and relativeRot <= 30 then
					DrawLine(objPos, playerPos, 0, 255, 0, 255) -- Just for visuals
					SetEntityTrafficlightOverride(v, 0)
				else
					DrawLine(objPos, playerPos, 255, 0, 0, 255) -- Just for visuals
					SetEntityTrafficlightOverride(v, 1)
				end
			end
			Wait(0)
		end
	end)
end



-- Checking all different variables, medium priority
CreateThread(function()
	while true do

		-- Player in vehicle
		if playerVeh ~= 0 then

			-- Siren on
			if IsVehicleSirenOn(playerVeh) then

				-- Thread not running yet
				if not threadsRunning then
					threadsRunning = true
					startObjectFindLoop()

					print("Starting thread!")
				end
			else
				if threadsRunning then
					threadsRunning = false

					print("Stopping thread!")
				end
			end
		end
		Wait(0)
	end
end)