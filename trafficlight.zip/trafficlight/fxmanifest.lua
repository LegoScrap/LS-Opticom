fx_version "cerulean"
game "gta5"

author "Puntherline"

client_script "client.lua"